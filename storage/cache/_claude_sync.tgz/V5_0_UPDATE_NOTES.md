97 Foundation Professional V5.0

- System currency standardized to LKR across donations, campaigns, forms, dashboard, sample data and schema. Existing installations should run database/upgrade_v5.php once.
- Portal Messages now support selected multi-user delivery and category broadcasts to Members, Volunteers, Administrators, all portal users or all active users, with private per-user delivery, notifications, audit logging and broadcast history.
- Dashboard Donation Performance now uses a real six-month verified/pending column chart sourced from database totals.
- Donation Details uses a compact professional Verified status tag.
- Branding & SEO now supports a browser tab logo/favicon managed from Admin and applied across public site, Admin login, Admin workspace and Member/Volunteer Portal.
- Added an Admin Website Image Size Guide and standardized cover-frame fitting guidance for hero, campaign, page, blog, event, cause, gallery and profile images.
