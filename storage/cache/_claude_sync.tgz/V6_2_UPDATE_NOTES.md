# 97 Foundation Professional V6.2

- Added public Donate tabs for Bank Transfer and Online Payment.
- Added any-amount LKR online donation flow with Admin-configured minimum/maximum limits and LKR 500/1,000/2,500/5,000 quick amounts.
- Added review → hosted gateway checkout → verified callback → status/receipt flow.
- Added modular `GatewayInterface`, payment service and PayHere adapter.
- Added server-side PayHere hash generation and callback checksum verification.
- Added encrypted-at-rest Admin gateway secrets when `PAYMENT_ENCRYPTION_KEY` is configured; environment variables are supported as the preferred production secret source.
- Added Developer Integration → Payment Gateway with sandbox/live mode, Merchant ID/Secret, API App ID/Secret, limits, receipt settings, URLs, connection test and integration status.
- Added Fundraising → Online Payments with transaction filters, status, search, export, details, gateway verification and refund request support.
- Added online payment Dashboard statistics and recent transactions.
- Added verified receipts and optional confirmation email through the host mail transport.
- Added idempotent webhook event handling and non-sensitive callback audit history.
- No card number, CVV or PIN data is stored by 97 Foundation.
