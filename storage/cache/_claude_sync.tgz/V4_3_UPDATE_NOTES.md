# 97 Foundation Professional V4.3 Update Notes

## Included in V4.3

- Volunteer Admin submenu split into **Volunteer List** and **Registration Management**.
- Emoji picker removed from public and Admin Live Chat.
- Professional **Close Chat** workflow with visitor notification, system timeline notice, reply lock and Start New Chat action.
- Admin Profile can securely change sign-in email and password.
- Slower, smoother nested Admin sidebar animation.
- Member/Volunteer Portal sidebar GET navigation upgraded to SPA behavior with branded Foundation logo spinner.
- Compact CR80 Member/Volunteer ID card with configured Foundation logo, privacy-safe QR, exact-size Print ID and Download PNG.
- Existing V4.2 pagination retained across Admin paginated modules.

## Database

No new database migration is required for V4.3. Continue to run `php database/upgrade_v4.php` once on installations that have not yet applied the V4/V4.1 chat columns.

## Deployment

Replace the application files, clear browser cache, and hard-refresh the Admin and Portal interfaces so the new CSS/JavaScript files load.
