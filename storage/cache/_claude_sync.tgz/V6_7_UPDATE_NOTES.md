# 97 Foundation Professional V6.7 — Member Production Readiness

V6.7 is a production-readiness release focused on member registration, member login, member approval/publication, CSRF/session reliability, member administration, mobile UI and safe error handling.

## Critical fixes
- Replaced the member Admin Save profile upsert with explicit transactional INSERT/UPDATE operations for broader MySQL/MariaDB compatibility and reliable rollback.
- Member registration creates a pending, private account with a unique Member ID and QR verification token.
- Approve / Activate now publishes the member automatically; reject/pending/inactive/suspended states automatically unpublish the member.
- Admin Edit can keep an active member private by clearing "Show on public Members page".
- Password policy for member registration, admin member creation/reset and portal password change is 8–12 characters, stored with Argon2id.
- Duplicate email, username, NIC/National ID and normalized contact number checks are handled with professional user-facing errors.
- Member auth routes are excluded from public SPA navigation to ensure every registration/login form receives fresh CAPTCHA and CSRF state.
- CSRF uses a signed double-submit browser cookie so shared-host PHP session rotation no longer causes false 419 responses.
- Production exception/fatal handling logs technical details to `storage/logs/php-error.log` and shows visitors a safe reference number.
- Non-critical notification/rate-limiter failures no longer take down a successful registration/login workflow.

## UI and responsive improvements
- Professional responsive Foundation Members hero with distinct Register and Member Login actions.
- Registration/login form refinements for 320, 375, 390, 414px phones, tablets and desktop.
- Live Chat launcher/panel respects mobile viewport and safe-area insets and stays separate from WhatsApp.
- Member Admin forms/cards and pagination receive responsive layout hardening.

## Production upgrade
Run once after uploading V6.7:

`php database/upgrade_v6_7.php`

Then run:

`php tools/member-production-check.php`

The checker does not modify data. It validates PHP/extensions, writable session/log paths, DB connectivity and member-related columns.
