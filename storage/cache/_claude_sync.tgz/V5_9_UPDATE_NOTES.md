# V5.9 Update Notes

## Included in this package

- Professional UI refinements for admin, portal and member-facing identity areas.
- Foundation logo now appears in more UI fallback positions instead of plain `97` blocks.
- Campaign cards in the admin area now show professional image fallbacks instead of blank placeholders.
- Admin-manageable images added for:
  - Foundation Portal login page
  - Member login page
  - Admin login background
  - Browser tab icon / favicon
- SEO and AEO fields extended for Sri Lanka targeting, especially:
  - Country
  - District / region
  - Locality / area
  - Keywords
  - Answer-engine summary
- Default project content updated for Sri Lanka / Polonnaruwa / Thambala positioning.
- Default timezone updated to `Asia/Colombo`.

## Admin path

Use **Admin → Branding, Visuals & SEO** to manage all new visual and search settings.

## Additional V5.9.1 refinements
- Premium split-screen Admin Login with uploaded background support and a professional gradient fallback.
- Official Foundation logo shown more prominently on Member Login, Member Registration and Portal Login.
- Broadcast recipient picker now uses the Foundation logo when a user has no profile image.
- Campaign editor shows the current cover image and uploaded images refresh immediately via file-version cache busting.
- Browser icon handling now includes favicon, shortcut icon and Apple touch icon with logo fallback.
- Existing V5.8 databases should run `php database/upgrade_v5_9.php` once.
