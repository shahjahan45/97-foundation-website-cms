# 97 Foundation Professional V6.6

## Live Portal HTTP 500 Fix

- Fixed a production SQL regression on `/portal`: the portal dashboard queried `events.featured_image`, but the database schema stores event artwork in `events.image_path`.
- The portal now correctly selects `image_path AS featured_image` for compatibility with existing view naming.
- Optional dashboard feeds (Events, Causes, Announcements) are now isolated so a temporary content-module/schema issue cannot take down the authenticated member/volunteer portal.
- Added a regression test that verifies the event image column matches the database schema.
- No database migration is required for this fix.
