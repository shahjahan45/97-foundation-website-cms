# 97 Foundation Professional V6.3 — Easy Payment Setup

V6.3 simplifies the V6.2 online-payment integration without weakening the server-side verification model.

## Admin improvements

- Developer Integration now shows **Easy Payment Setup**.
- Normal hosted checkout needs only **Merchant ID + Merchant Secret**.
- Sandbox/Live selection is presented as a simple first step.
- Donation limits and Enable Online Payments are in the same quick setup wizard.
- **Save & Test Setup** saves the configuration and immediately validates checkout credentials.
- Merchant API App ID/Secret, refunds/status sync and receipt settings are moved under **Advanced Settings**.
- Setup readiness clearly shows secure secret storage, checkout credentials and validation status.
- Exact webhook, return and cancel URLs are shown automatically.

## Secure secret storage

- Server environment keys are still preferred when configured.
- If no `PAYMENT_ENCRYPTION_KEY` / `APP_KEY` exists, the application automatically generates a cryptographically-random encryption key in `storage/private/payment.key`.
- The generated key is outside the public web area, protected by the project's storage access rules and written with restrictive permissions where supported.
- Gateway secrets remain encrypted with AES-256-GCM and are never rendered back into frontend HTML.

## Donor checkout improvements

Online Payment is now shorter and clearer:

1. Choose a quick/custom LKR amount and fund/campaign.
2. Enter name, phone and optional email.
3. Review and continue to the hosted gateway.

Address/city are available only under optional additional details. The gateway determines available card/wallet/banking methods, so donors no longer need to select a preference before checkout.

## Database

No new V6.3 migration is required. Existing installations still need the V6.2 payment migration once:

```bash
php database/upgrade_v6_2.php
```
