# 97 Foundation Professional V6.0

## Professional Notification Centre

- Header notification bells in both Admin and Member/Volunteer Portal now open a professional in-page notification window instead of navigating away immediately.
- Notification drawer shows complete title/message content, date/time, type/status, read/unread state and optional related-item action.
- Added individual **Mark as Read**, **Mark All as Read**, All/Unread filters and progressive **Load older notifications** support.
- Notification counts update dynamically across header badges and Portal navigation.
- Added responsive full-screen notification experience for mobile, compact floating panel for desktop/tablet, internal scrolling and subtle open/close animation.
- Redesigned full Admin and Portal Notification Centre pages with professional read/unread cards and pagination.
- Opening the Notification Centre no longer automatically marks everything as read; users control read state explicitly.
- No database migration is required for V6.0.
