# 97 Foundation Professional V4.8

## Account Security
- Added **System → Account Security** as a dedicated administrator security workspace.
- Moved sign-in email and password updates out of the My Profile form.
- Current-password verification, unique-email validation, Argon2id password hashing, session rotation and password-match UI remain enforced.
- Added direct access to Security & 2FA from the Account Security page.

## Donation Verification + CRUD
- Rebuilt Donation Verification into a professional administration data table inspired by modern SaaS dashboards.
- Added date, status and keyword filters plus preserved server-side pagination.
- Added **Create, Read/View, Edit/Update and Delete** administration flows for donation records.
- Added dedicated donation editor and details pages.
- Added verification history and quick Approve / Reject controls on the details page.
- Donation deletion is restricted to Super Admin because it permanently changes historical and public totals.

## Admin CRUD coverage
The existing core data modules retain create/edit/update/delete controls where a resource is genuinely CRUD-based: campaigns, causes, donation accounts, events, gallery, members, posts, social links, volunteers and content records. Live Chat remains lifecycle-based (reply/status/note/close/delete), while Branding, 2FA and Account Security are singleton settings rather than deletable resources.

No database migration is required for V4.8.
