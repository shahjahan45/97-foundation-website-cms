97 Foundation Professional V5.2 — Full-Width Artwork Hero Slider

- Homepage hero now renders uploaded 1920×900 artwork as the actual full-width slide image.
- Removed legacy previous/next arrows and duplicate white assistance pill from the hero.
- Removed duplicated HTML headline/buttons/logo overlays from hero artwork mode.
- Automatic 5.6-second transitions with smooth fade, pause on hover/focus, subtle progress indicators, keyboard arrows and mobile swipe.
- First hero image is preloaded and eager/high priority; later slides lazy load.
- Admin Hero Slider continues to support multiple slides with create/edit/delete/order/active controls.
- No database migration required.
