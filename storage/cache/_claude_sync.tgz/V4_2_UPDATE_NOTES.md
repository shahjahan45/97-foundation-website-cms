# 97 Foundation Professional V4.2 Update Notes

## Database
No new database migration is required when upgrading from Professional V4.1. Run the existing `php database/upgrade_v4.php` only if the V4/V4.1 database upgrade was not previously applied.

## Main changes
- Shared Admin pagination is now standardized and visible on all paginated Admin modules.
- Public Live Chat now switches cleanly from Start state to Chat-only Active state.
- Admin sidebar nested menus use smooth expand/collapse transitions.
- Admin Live Chat conversation pagination supports AJAX rows-per-page selection.

## Upgrade
Replace the application files with this V4.2 package while keeping your `config.php`, `public/uploads/`, and `storage/private/` production data backed up and preserved.
