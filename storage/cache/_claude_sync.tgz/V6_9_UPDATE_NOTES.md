# 97 Foundation Professional V6.9

- Redesigned the public Foundation Members cards for a more balanced premium directory layout.
- Member photos now display completely with `object-fit: contain`, preserving the uploaded aspect ratio without stretching or face/body cropping.
- Added reserved 4:3 media frames, skeleton shimmer loading states, async decoding, eager priority for above-the-fold member photos and lazy loading for later cards.
- New member photo uploads automatically generate 360px and 720px WebP responsive variants when GD/WebP is available.
- Added `php tools/optimize-member-images.php` to generate optimized WebP variants for existing member photos without modifying database records.
- Added long-lived immutable browser caching for uploaded JPG/PNG/WebP assets.
- Card spacing, typography, verification badge, hover states, buttons and low-member-count alignment were refined across desktop, tablet and mobile.
- No database migration is required.
