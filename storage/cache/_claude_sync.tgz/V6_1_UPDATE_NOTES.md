97 Foundation Professional V6.1

- Notification popup reduced to a compact professional floating window on desktop/tablet.
- Notification overlay now starts below the application header, keeping the header and notification bell visible.
- Removed the heavy full-screen background blur; the page remains clearly visible behind the notification panel.
- Reduced header, toolbar, notification-card and footer spacing while preserving complete notification messages.
- Mobile notification experience now uses an inset sheet below the website/admin header instead of covering the complete screen/header.
- Read/unread state, filters, Mark as Read, Mark All as Read, scrolling and Load Older remain unchanged.
