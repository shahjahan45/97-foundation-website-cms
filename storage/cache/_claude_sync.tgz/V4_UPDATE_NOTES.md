# 97 Foundation Professional V4 Update Notes

## Required database step
For a V3 installation, back up the database and uploads, replace the code, then run:

```bash
php database/upgrade_v4.php
```

The V4 migration adds the independent campaign Active/Inactive flag, useful indexes for large paginated Admin queues, and verifies the Live Chat tables exist.

## Main V4 changes
- Donate Now, About Us and News & Blog stay on one line in desktop navigation.
- New responsive glassmorphism footer with real donation-page QR and dynamic database counts.
- Campaigns now have separate lifecycle status, Active/Inactive, and Public/Hidden controls.
- Cause Areas have quick Activate/Deactivate controls.
- Donation Verification has search, status filters, 10/25/50/100 page-size selection, pagination, queue counters, inline proof viewer in a new tab, and approve/reject controls.
- Large Admin modules are paginated; Website Content uses independent pagination for Pages, Sections and Hero Slides.
- Volunteers sidebar is expandable with a dedicated Volunteer Applications approval queue.
- Public Live Chat uses a modern SVG support icon, explicit base URL, safer JSON handling, polling, client-side error messages and no full-page loader during chat AJAX requests.
- Admin Live Chat uses a professional 3-column support workspace on large screens and responsive layouts on smaller screens.

## Live Chat troubleshooting
If an existing installation still reports a chat error, run `php database/upgrade_v3.php` once, then `php database/upgrade_v4.php`. Clear the browser cache with Ctrl+F5. The V4 migration also recreates missing chat tables with `CREATE TABLE IF NOT EXISTS`.

## V4.1 Live Chat + Admin Navigation Update — 2026-08-12

### Live Chat Admin
- Fixed-height one-screen workspace; browser/page scrolling is disabled on the Live Chat admin page.
- Three-panel Conversations / Chat / Visitor Details layout with independent internal scrolling.
- AJAX conversation selection, status filtering, search, pagination, reply, status update, support-note save and Super Admin delete.
- 4-second secure polling for received messages; only the message thread scrolls to the newest message.
- Shared unread tracking, visitor presence timestamps and internal support notes.
- Enter sends, Shift+Enter adds a line break; compact emoji shortcuts are available in the composer.
- Responsive panel switcher for smaller laptops, tablets and mobile screens.

### Admin Sidebar
- Replaced section-label navigation with expandable SaaS-style nested groups:
  - Fundraising
  - People & Community
  - Support & Messages
  - Content & Website
  - System
- Existing routes and permissions remain unchanged.

### Database
Run the existing idempotent upgrade once after replacing the application files:

```bash
php database/upgrade_v4.php
```

This adds `admin_notes`, `admin_last_read_at`, `visitor_last_seen_at`, and the chat presence index when missing.

### Footer
- Replaced “Made with ♥ for Humanity.” with “Fully Developed by 97 Foundation IT Team.”
