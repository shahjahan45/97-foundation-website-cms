# 97 Foundation Professional V5.1 — Premium Homepage Slider

- Removed the large previous/next circular arrow controls from the homepage hero.
- Removed the duplicate “Need assistance?” floating pill while keeping the normal Live Chat launcher.
- Hero images now fill the entire responsive hero frame with `object-fit: cover`; the old black split/background block has been removed.
- Reduced overlay darkness so uploaded photography remains clearly visible while hero text stays readable.
- Active hero slides auto-rotate every 6.5 seconds with a professional cross-fade and subtle image motion.
- Slider pauses on hover, pauses when the browser tab is hidden, and resumes safely.
- Touch swipe navigation is supported on mobile/tablet.
- Progress-style dot navigation remains compact and unobtrusive.
- Admin → Content & Website → Hero Slider already supports adding multiple slides, ordering, activation/deactivation, editing and deletion.
- Recommended hero image size remains 1920 × 900 px.

No database migration is required.
