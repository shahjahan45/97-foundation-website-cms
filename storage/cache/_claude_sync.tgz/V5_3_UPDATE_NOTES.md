97 Foundation Professional V5.3

- Restored the classic hero headline, supporting text, action buttons and community-support badge over the full-width hero image.
- Kept the V5.2 full-width responsive image presentation and no large navigation arrows.
- Rebuilt hero automatic rotation using a reliable 5.6-second timeout scheduler. Autoplay no longer stops just because the operating system requests reduced animation; reduced-motion users simply receive reduced transition effects.
- Hero pauses on hover/focus, resumes after interaction, supports dots, keyboard navigation and mobile swipe.
- Admin Hero Slider editor once again exposes headline, supporting copy and both CTA buttons for every slide.
