97 Foundation Professional V4.5

- Portal My Profile page redesigned professionally and oversized role badge removed.
- Public verification page upgraded to a cleaner premium verification card.
- Admin My Profile UI redesigned to a more professional glassmorphism dashboard style.
- Additional glassmorphism polish applied across the admin and portal interface.
