97 Foundation Professional V5.7 — Member Registration, Responsive Hero & Mobile/Tablet Upgrade

Database upgrade required once: php database/upgrade_v5_7.php

Key changes:
- Public member registration and separate member login.
- Automatic unique Member ID and QR verification token.
- Member approval/rejection lifecycle, admin QR management and secure password reset.
- Member dashboard announcements/events/causes and personal identity information.
- Admin-managed floating WhatsApp number/button.
- Hero desktop + mobile images, scheduling, preview, drag-and-drop order.
- Mobile/tablet responsive pass across inner pages and portal.
