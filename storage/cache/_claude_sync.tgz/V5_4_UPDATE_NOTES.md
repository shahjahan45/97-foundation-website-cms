# 97 Foundation Professional V5.4

- Added **Admin → Content & Website → Website Content Manager → Home Page** as a dedicated professional homepage builder.
- Homepage About image is now directly replaceable from Admin.
- Homepage section headings, descriptions, buttons, visibility and dynamic item counts are centrally editable.
- Hero content/images remain managed in the Hero Slider tab.
- Cause, Campaign, Gallery, Event and News images remain managed in their dedicated CRUD modules and feed the homepage automatically.
- New published Events and News/Blog posts automatically appear on the homepage.
- Footer Contact Info icons were replaced with consistent professional SVG icons.
- Existing V5.x databases must run `php database/upgrade_v5_4.php` once.
