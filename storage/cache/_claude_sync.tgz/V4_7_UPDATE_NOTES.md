97 Foundation Professional V4.7

- Admin Edit Profile is now one unified professional component with personal information, profile picture, account security, and administrator-controlled information sections.
- Account Email & Password is no longer a separate large card.
- Added password show/hide controls and live password-match validation.
- Social media rendering now uses automatic professional SVG platform icons instead of raw Font Awesome class text or oversized characters.
- Footer social icons use consistent containers, spacing, brand-aware hover colors, tooltips and responsive behavior.
- Social Media Admin editor now auto-detects the correct platform icon and removes the need for manual icon class/letter input.
