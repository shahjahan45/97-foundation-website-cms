97 Foundation Professional V4.9

Critical regression fixes:
- Fixed HTTP 500 on /admin/donations caused by a PHP method-signature collision between DonationAdminController::view() and the base Controller::view() renderer. The donation details action is now DonationAdminController::details().
- Fixed the Admin loader remaining permanently visible after using the browser Back / Forward buttons. The loader now recovers correctly from browser bfcache, pageshow, popstate, window load and tab visibility restoration.
- Added class-loading regression tests so inheritance/signature fatals are caught before packaging, not just syntax linted.
