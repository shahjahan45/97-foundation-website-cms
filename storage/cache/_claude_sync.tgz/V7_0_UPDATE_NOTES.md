97 Foundation Professional V7.0

- Redesigned only the public Foundation Members directory frontend; member data, queries, routes, authentication, verification and backend business rules are unchanged.
- Large desktop uses four compact cards per row; tablet uses three; small tablet/mobile use two columns down to 320px.
- Cards now include compact verified badge, member role, name, ID, joined date, member-since duration, active state and the existing verification/profile link as the primary View Full Profile action.
- Member photos use consistent responsive media frames with existing skeleton loading and optimized image sources.
- Added lightweight client-side member search, active-status filtering, sorting and presentation-only pagination without changing server queries or records returned.
- Added responsive filter toolbar and compact pagination controls with accessible labels and visible focus states.
- No database migration required.
