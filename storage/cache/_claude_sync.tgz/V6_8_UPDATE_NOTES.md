# 97 Foundation Professional V6.8 — Live Configuration & Production Diagnostic Fix

- Added deployment-safe `config.local.php` support so live database credentials survive future source-code ZIP replacements.
- Environment variables remain supported and take precedence.
- Added `config.local.example.php` for the live `97foundation.datacubex.com` installation.
- Added `tools/production-check.php` to verify PHP extensions, writable storage, database connection, core tables and important schema upgrades.
- Added `tools/find-error-reference.php` so branded production error references can be matched to the protected server log without exposing details publicly.
- Protected root-level `config.local.php` from web access through `.htaccess`.
- No database migration is introduced by V6.8; existing V6.7 migration requirements remain.
