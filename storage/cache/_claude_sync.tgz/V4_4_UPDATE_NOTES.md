# 97 Foundation Professional V4.4 Update Notes

- Added Admin-managed **Organization Website** branding setting. It automatically appears on Member/Volunteer ID cards and downloaded PNG identity cards.
- Rebuilt the public Foundation Members directory into compact professional cards with up to **5 members per row** on wide desktop screens and responsive breakpoints below that.
- Fixed public Live Chat closed-conversation UI by moving the required styles into the public stylesheet, compacting the system close notice, and presenting a professional completed-conversation action card.
- Replaced the large blocking Member Portal loading overlay with a small non-blocking Foundation route-loading indicator.
- Preserved CR80 identity-card printing/download behavior, QR privacy protections, portal SPA navigation, V4.2 pagination, and V4.3 support controls.
