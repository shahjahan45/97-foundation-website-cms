97 Foundation Professional V6.5

LIVE MEMBER/ADMIN FORM RELIABILITY
- Fixes false HTTP 419 CSRF failures seen on live subdomains for Member Registration, Member Login and Admin member save/update forms.
- Uses protected application session storage at storage/private/sessions when writable.
- Supports common reverse-proxy/CDN HTTPS headers.
- Prevents dynamic HTML/CSRF token caching.
- Adds signed CSRF cookie fallback and a professional session-expired recovery page.

FAVICON
- `/favicon.ico` now resolves through the Admin-managed tab icon/Foundation logo with a safe fallback.

NO DATABASE MIGRATION REQUIRED.
