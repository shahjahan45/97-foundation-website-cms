<?php
$home=file_get_contents(__DIR__.'/../app/Views/home.php');
$js=file_get_contents(__DIR__.'/../public/assets/js/app.js');
$css=file_get_contents(__DIR__.'/../public/assets/css/app.css');
$admin=file_get_contents(__DIR__.'/../app/Views/admin/content.php');
$checks=[
 'hero overlay title'=>str_contains($home,'hero-overlay-content')&&str_contains($home,"<h1><?=e(\$slide['title']"),
 'hero buttons restored'=>str_contains($home,'button_text')&&str_contains($home,'secondary_text'),
 'no arrow controls in home'=>!str_contains($home,'data-hero-prev')&&!str_contains($home,'data-hero-next'),
 'timeout autoplay'=>str_contains($js,'setTimeout(()=>{go(i+1);schedule();},delay)'),
 '5600 interval'=>str_contains($js,'const delay=5600'),
 'admin overlay fields'=>str_contains($admin,'Primary Button Text')&&str_contains($admin,'Secondary Button Text'),
 'full image cover'=>str_contains($css,'.hero-artwork-slider .hero-slide-image')&&str_contains($css,'object-fit:cover'),
];
$ok=true;foreach($checks as $name=>$pass){echo ($pass?'PASS ':'FAIL ').$name.PHP_EOL;$ok=$ok&&$pass;}exit($ok?0:1);
