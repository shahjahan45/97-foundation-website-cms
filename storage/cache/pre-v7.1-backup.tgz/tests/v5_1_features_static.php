<?php
$home=file_get_contents(__DIR__.'/../app/Views/home.php');
$css=file_get_contents(__DIR__.'/../public/assets/css/app.css');
$js=file_get_contents(__DIR__.'/../public/assets/js/app.js');
$admin=file_get_contents(__DIR__.'/../app/Views/admin/content.php');
$checks=[
 'Removed previous/next hero arrows'=>!str_contains($home,'data-hero-prev')&&!str_contains($home,'data-hero-next'),
 'Removed duplicate assistance pill'=>!str_contains($home,'Need assistance?')&&!str_contains($home,'live-pill'),
 'Full responsive hero image element'=>str_contains($home,'class="hero-media"')&&str_contains($css,'object-fit:cover'),
 'Autoplay configured'=>str_contains($home,'data-hero-autoplay="6500"')&&str_contains($js,'setInterval'),
 'Slider dot navigation'=>str_contains($home,'data-hero-dot'),
 'Touch swipe supported'=>str_contains($js,'touchstart')&&str_contains($js,'touchend'),
 'Admin supports multiple hero slides'=>str_contains($admin,'Hero Slide Editor')&&str_contains($admin,'New Slide')&&str_contains($admin,'admin/slides/save'),
];
$ok=true;foreach($checks as $name=>$pass){echo ($pass?'PASS':'FAIL').": $name\n";$ok=$ok&&$pass;}exit($ok?0:1);
