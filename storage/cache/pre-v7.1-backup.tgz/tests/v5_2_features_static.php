<?php
$checks=[];
$home=file_get_contents(__DIR__.'/../app/Views/home.php');
$css=file_get_contents(__DIR__.'/../public/assets/css/app.css');
$js=file_get_contents(__DIR__.'/../public/assets/js/app.js');
$admin=file_get_contents(__DIR__.'/../app/Views/admin/content.php');
$checks['full-width hero image']=str_contains($home,'hero-slide-image')&&!str_contains($home,'data-hero-prev')&&!str_contains($home,'data-hero-next');
$checks['cover image rendering']=str_contains($css,'object-fit:cover')&&str_contains($css,'object-position:center center');
$checks['auto slider scheduler']=str_contains($js,'5600')&&(str_contains($js,'setInterval(()=>go(i+1),5600)')||str_contains($js,'setTimeout(()=>{go(i+1);schedule();},delay)'));
$checks['swipe support']=str_contains($js,'touchstart')&&str_contains($js,'touchend');
$checks['keyboard support']=str_contains($js,'ArrowRight')&&str_contains($js,'ArrowLeft');
$checks['lazy later slides']=str_contains($home,'loading="lazy" fetchpriority="low"');
$checks['admin hero management']=str_contains($admin,'Hero Slide Editor')&&str_contains($admin,'Display Order');
foreach($checks as $name=>$ok){echo ($ok?'PASS':'FAIL')." - $name\n";if(!$ok)exit(1);}echo "V5.2 full-width hero foundation checks passed.\n";
