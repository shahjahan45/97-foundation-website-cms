<?php
$u=$user??\App\Core\Auth::user();
$unread=unread_notifications((int)($u['id']??0));
$logo=setting('foundation','logo_path','');
$logoEnabled=setting('foundation','logo_enabled','1')==='1';
$favicon=setting('foundation','favicon_path','');
$path=current_path();
try{$pendingVolunteerCount=(int)(\App\Core\Database::one('SELECT COUNT(*) c FROM volunteers WHERE status="pending"')['c']??0);}catch(\Throwable){$pendingVolunteerCount=0;}
try{$pendingMemberCount=(int)(\App\Core\Database::one('SELECT COUNT(*) c FROM users WHERE role="member" AND status="pending"')['c']??0);}catch(\Throwable){$pendingMemberCount=0;}
try{$openLiveChatCount=(int)(\App\Core\Database::one('SELECT COUNT(*) c FROM chat_conversations WHERE status<>"closed"')['c']??0);}catch(\Throwable){$openLiveChatCount=0;}
$isFundraising=str_starts_with($path,'/admin/campaigns')||str_starts_with($path,'/admin/donations')||str_starts_with($path,'/admin/donation-settings')||str_starts_with($path,'/admin/online-payments');
$isPeople=str_starts_with($path,'/admin/volunteers')||str_starts_with($path,'/admin/members');
$isSupport=str_starts_with($path,'/admin/messages')||str_starts_with($path,'/admin/live-chat');
$isContent=str_starts_with($path,'/admin/content')||str_starts_with($path,'/admin/causes')||str_starts_with($path,'/admin/events')||str_starts_with($path,'/admin/gallery')||str_starts_with($path,'/admin/posts')||str_starts_with($path,'/admin/branding');
$isSystem=str_starts_with($path,'/admin/social')||str_starts_with($path,'/admin/security')||str_starts_with($path,'/admin/account-security')||str_starts_with($path,'/admin/profile');
$isDeveloper=str_starts_with($path,'/admin/developer');
$bodyClass=trim((string)($adminBodyClass??''));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?=e($adminTitle??'Admin')?> | 97 Foundation</title>
<?php $tabIcon=$favicon?public_upload($favicon):($logo?public_upload($logo):''); if($tabIcon):?><link rel="icon" href="<?=e($tabIcon)?>"><link rel="apple-touch-icon" href="<?=e($tabIcon)?>"><?php endif;?>
<link rel="stylesheet" href="<?=asset('css/admin.css')?>">
</head>
<body class="<?=e($bodyClass)?>">
<div id="admin-loader" class="admin-loader show" aria-hidden="false"><div><?php if($logoEnabled&&$logo):?><img src="<?=e(public_upload($logo))?>" alt=""><?php else:?><b>97</b><?php endif;?><i></i><span>Loading secure workspace…</span></div></div>
<div class="admin-shell">
<aside class="sidebar">
    <a class="side-brand" href="<?=url('admin')?>">
        <?php if($logoEnabled&&$logo):?><img class="admin-brand-logo" src="<?=e(public_upload($logo))?>" alt="97 Foundation"><?php else:?><span class="admin-logo">97</span><?php endif;?>
        <div><b>97 FOUNDATION</b><small>Administration Workspace</small></div>
    </a>

    <nav aria-label="Admin navigation">
        <a class="side-dashboard <?=nav_active('admin')?>" href="<?=url('admin')?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg></span><span>Dashboard</span></a>

        <div class="side-group <?=$isFundraising?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isFundraising?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><path d="M4 18V9l8-5 8 5v9"/><path d="M8 18v-5h8v5M3 20h18"/></svg></span><span>Fundraising</span><i>›</i></button>
            <div class="side-submenu">
                <a class="<?=nav_active('admin/campaigns')?>" href="<?=url('admin/campaigns')?>"><span class="side-sub-icon">◫</span><span>Campaigns</span></a>
                <a class="<?=nav_active('admin/donations')?>" href="<?=url('admin/donations')?>"><span class="side-sub-icon">◉</span><span>Donations</span></a>
                <a class="<?=nav_active('admin/donation-settings')?>" href="<?=url('admin/donation-settings')?>"><span class="side-sub-icon">▤</span><span>Donation Settings</span></a>
                <?php if(\App\Core\Auth::can('view_online_payments')):?><a class="<?=nav_active('admin/online-payments',true)?>" href="<?=url('admin/online-payments')?>"><span class="side-sub-icon">◆</span><span>Online Payments</span></a><?php endif;?>
            </div>
        </div>

        <div class="side-group <?=$isPeople?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isPeople?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><path d="M16 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="3"/><path d="M17 11a3 3 0 0 0 0-6M21 20v-2a4 4 0 0 0-3-3.9"/></svg></span><span>People & Community</span><?php if($pendingVolunteerCount):?><em><?=$pendingVolunteerCount?></em><?php endif;?><i>›</i></button>
            <div class="side-submenu">
                <a class="<?=nav_active('admin/members')?>" href="<?=url('admin/members')?>"><span class="side-sub-icon">♧</span><span>Member List</span></a><a class="<?=nav_active('admin/members/registrations')?>" href="<?=url('admin/members/registrations')?>"><span class="side-sub-icon">▧</span><span>Member Registrations</span><?php if($pendingMemberCount):?><em><?=$pendingMemberCount?></em><?php endif;?></a>
                <a class="<?=nav_active('admin/volunteers')?>" href="<?=url('admin/volunteers')?>"><span class="side-sub-icon">♙</span><span>Volunteer List</span></a>
                <a class="<?=nav_active('admin/volunteers/applications')?>" href="<?=url('admin/volunteers/applications')?>"><span class="side-sub-icon">▧</span><span>Registration Management</span><?php if($pendingVolunteerCount):?><em><?=$pendingVolunteerCount?></em><?php endif;?></a>
            </div>
        </div>

        <div class="side-group <?=$isSupport?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isSupport?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><path d="M21 12a8 8 0 0 1-8.5 8 9 9 0 0 1-3.6-.8L4 21l1.5-4.4A8 8 0 1 1 21 12Z"/><path d="M8 12h.01M12 12h.01M16 12h.01"/></svg></span><span>Support & Messages</span><?php if($openLiveChatCount):?><em><?=$openLiveChatCount?></em><?php endif;?><i>›</i></button>
            <div class="side-submenu">
                <a class="<?=nav_active('admin/messages')?>" href="<?=url('admin/messages')?>"><span class="side-sub-icon">✉</span><span>Portal Messages</span></a>
                <a class="<?=nav_active('admin/live-chat')?>" href="<?=url('admin/live-chat')?>"><span class="side-sub-icon"><svg class="side-chat-icon" viewBox="0 0 24 24"><path d="M20 11.5a7.5 7.5 0 0 1-8 7.5 8.7 8.7 0 0 1-3.3-.7L4 20l1.4-4.1A7.2 7.2 0 0 1 4 11.5 7.5 7.5 0 0 1 12 4a7.5 7.5 0 0 1 8 7.5Z"/><path d="M8.5 11.5h.01M12 11.5h.01M15.5 11.5h.01"/></svg></span><span>Website Live Chat</span><?php if($openLiveChatCount):?><em><?=$openLiveChatCount?></em><?php endif;?></a>
            </div>
        </div>

        <div class="side-group <?=$isContent?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isContent?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5M8 17h3"/></svg></span><span>Content & Website</span><i>›</i></button>
            <div class="side-submenu">
                <a class="<?=nav_active('admin/content')?>" href="<?=url('admin/content')?>"><span class="side-sub-icon">✎</span><span>Website Content</span></a>
                <a class="<?=nav_active('admin/causes')?>" href="<?=url('admin/causes')?>"><span class="side-sub-icon">♡</span><span>Cause Areas</span></a>
                <a class="<?=nav_active('admin/events')?>" href="<?=url('admin/events')?>"><span class="side-sub-icon">◷</span><span>Events</span></a>
                <a class="<?=nav_active('admin/gallery')?>" href="<?=url('admin/gallery')?>"><span class="side-sub-icon">▧</span><span>Gallery</span></a>
                <a class="<?=nav_active('admin/posts')?>" href="<?=url('admin/posts')?>"><span class="side-sub-icon">▤</span><span>News & Blog</span></a>
                <a class="<?=nav_active('admin/branding')?>" href="<?=url('admin/branding')?>"><span class="side-sub-icon">✦</span><span>Branding & SEO</span></a>
            </div>
        </div>

        <?php if(\App\Core\Auth::can('manage_payment_gateway')):?><div class="side-group <?=$isDeveloper?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isDeveloper?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><path d="M8 9 4 12l4 3M16 9l4 3-4 3M14 5l-4 14"/></svg></span><span>Developer Integration</span><i>›</i></button>
            <div class="side-submenu"><a class="<?=nav_active('admin/developer/payment-gateway',true)?>" href="<?=url('admin/developer/payment-gateway')?>"><span class="side-sub-icon">◇</span><span title="Payment Gateway">Easy Payment Setup</span></a></div>
        </div><?php endif;?>

        <div class="side-group <?=$isSystem?'open active':''?>" data-side-group>
            <button type="button" class="side-parent" data-side-toggle aria-expanded="<?=$isSystem?'true':'false'?>"><span class="side-nav-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21h-4v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H3v-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6V3h4v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.1v4H21a1.7 1.7 0 0 0-1.6 1Z"/></svg></span><span>System</span><i>›</i></button>
            <div class="side-submenu">
                <a class="<?=nav_active('admin/social')?>" href="<?=url('admin/social')?>"><span class="side-sub-icon">◎</span><span>Social Media</span></a>
                <a class="<?=nav_active('admin/security')?>" href="<?=url('admin/security')?>"><span class="side-sub-icon">⌾</span><span>Security & 2FA</span></a>
                <a class="<?=nav_active('admin/account-security')?>" href="<?=url('admin/account-security')?>"><span class="side-sub-icon">▣</span><span>Account Security</span></a>
                <a class="<?=nav_active('admin/profile')?>" href="<?=url('admin/profile')?>"><span class="side-sub-icon">♙</span><span>Admin Account</span></a>
                <a href="<?=url('')?>" target="_blank"><span class="side-sub-icon">↗</span><span>View Website</span></a>
            </div>
        </div>
    </nav>

    <div class="side-footer">
        <div class="side-user-mini"><span><?=e(strtoupper(substr($u['name']??'A',0,1)))?></span><div><small>Signed in as</small><b><?=e($u['name']??'Administrator')?></b></div></div>
        <form action="<?=url('admin/logout')?>" method="post"><?=csrf_field()?><button><span>⇥</span> Logout</button></form>
    </div>
</aside>

<section class="admin-main">
    <header class="admin-top">
        <div class="admin-title-area"><button class="admin-menu" data-admin-menu aria-label="Open navigation">☰</button><div><h1><?=e($adminTitle??'Admin Dashboard')?></h1><small>Welcome back, <?=e($u['name']??'Admin')?>. 👋</small></div></div>
        <div class="admin-user">
            <label class="search"><span>⌕</span><input type="search" placeholder="Search admin menu…" data-admin-search aria-label="Search admin navigation"></label>
            <button class="bell notification-bell" type="button" data-notification-toggle aria-label="Open notifications" aria-expanded="false" title="Notifications"><svg class="bell-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg><i data-notification-count <?=$unread?'':'hidden'?>><?=$unread?></i></button>
            <a class="avatar-wrap" href="<?=url('admin/profile')?>"><?php if(!empty($u['profile_photo'])):?><img class="avatar-img" src="<?=e(public_upload($u['profile_photo']))?>" alt="Profile"><?php else:?><span class="avatar"><?=e(strtoupper(substr($u['name']??'A',0,1)))?></span><?php endif;?><div><b><?=e($u['name']??'Admin')?></b><small><?=e(str_replace('_',' ',ucwords($u['role']??'administrator','_')))?></small></div><span class="profile-chevron">⌄</span></a>
        </div>
    </header>
    <div class="admin-content"><?php if($s=flash('success')):?><div class="alert success" data-auto-dismiss><?=e($s)?></div><?php endif;?><?php if($s=flash('error')):?><div class="alert danger" data-auto-dismiss><?=e($s)?></div><?php endif;?><?=$content?></div>
</section>
</div>
<?=notification_panel_shell('admin',$unread)?>
<div class="modal-shell" data-modal-shell><div class="modal-backdrop" data-modal-close></div><div class="modal-card"><button class="modal-x" data-modal-close>×</button><div data-modal-content></div></div></div>
<?php if(($adminPage??'')==='member-details'):?><script src="<?=asset('js/vendor/qrcode.min.js')?>" defer></script><?php endif;?><script src="<?=asset('js/admin.js')?>" defer></script><script src="<?=asset('js/notifications.js')?>" defer></script>
<?php if(($adminPage??'')==='live-chat'):?><script src="<?=asset('js/admin-live-chat.js')?>" defer></script><?php endif;?>
</body>
</html>
