<?php
$foundation=$settings['foundation']??[];
$seoSettings=$settings['seo']??[];
$seoData=$seo??[];
$pageTitle=$seoData['title']??($title??($seoSettings['default_title']??($foundation['name']??'97 Foundation')));
$description=$seoData['description']??($seoSettings['default_description']??'97 Foundation — Hope. Help. Humanity.');
$canonical=absolute_url(ltrim(current_path(),'/'));
$logo=$foundation['logo_path']??'';$logoEnabled=($foundation['logo_enabled']??'1')==='1';$favicon=$foundation['favicon_path']??'';
$orgName=$foundation['name']??'97 Foundation';$orgWebsite=trim((string)($foundation['website']??''))?:absolute_url('');
$socialImage=$seoData['image']??($seoSettings['social_image']??'');$socialImageUrl=$socialImage?(preg_match('~^https?://~i',(string)$socialImage)?(string)$socialImage:absolute_url('public/uploads/'.ltrim((string)$socialImage,'/'))):'';
$targetCountry=$seoSettings['target_country']??'Sri Lanka';$targetDistrict=$seoSettings['target_district']??'Polonnaruwa';$targetLocality=$seoSettings['target_locality']??'Thambala';$keywords=$seoSettings['keywords']??'';
$orgAddress=$foundation['address']??($targetLocality.', '.$targetDistrict.', '.$targetCountry);
$schema=[
  '@context'=>'https://schema.org','@type'=>'NGO','name'=>$orgName,'url'=>$orgWebsite,
  'description'=>$description,'slogan'=>$foundation['tagline']??null,'email'=>$foundation['email']??null,'telephone'=>$foundation['phone']??null,
  'logo'=>$logo?absolute_url('public/uploads/'.ltrim((string)$logo,'/')):null,
  'image'=>$socialImageUrl?:null,
  'address'=>['@type'=>'PostalAddress','streetAddress'=>$orgAddress,'addressLocality'=>$targetLocality,'addressRegion'=>$targetDistrict,'addressCountry'=>$targetCountry],
  'areaServed'=>['@type'=>'Place','name'=>$targetLocality.', '.$targetDistrict.', '.$targetCountry],
];
$socialLinks=\App\Core\Database::all('SELECT * FROM social_links WHERE is_active=1 ORDER BY sort_order,id');
$schema['sameAs']=array_values(array_filter(array_map(fn($row)=>trim((string)($row['url']??'')),$socialLinks)));
try{$footerVolunteerCount=(int)(\App\Core\Database::one('SELECT COUNT(*) c FROM volunteers WHERE status IN("approved","active")')['c']??0);$footerDonationCount=(int)(\App\Core\Database::one('SELECT COUNT(*) c FROM donations WHERE status="approved"')['c']??0);}catch(\Throwable){$footerVolunteerCount=0;$footerDonationCount=0;}
$websiteSchema=['@context'=>'https://schema.org','@type'=>'WebSite','@id'=>$orgWebsite.'#website','name'=>$orgName,'url'=>$orgWebsite,'inLanguage'=>'en-LK','publisher'=>['@type'=>'Organization','name'=>$orgName,'url'=>$orgWebsite]];
$pageSchema=['@context'=>'https://schema.org','@type'=>'WebPage','name'=>$pageTitle,'description'=>$description,'url'=>$canonical,'isPartOf'=>['@type'=>'WebSite','name'=>$orgName,'url'=>$orgWebsite],'about'=>['@type'=>'Thing','name'=>$targetLocality.', '.$targetDistrict.', '.$targetCountry]]; if(!empty($post)){ $pageSchema=['@context'=>'https://schema.org','@type'=>'Article','headline'=>$post['title'],'description'=>$post['meta_description']?:($post['excerpt']??$description),'datePublished'=>$post['published_at'],'dateModified'=>$post['updated_at']??$post['published_at'],'mainEntityOfPage'=>$canonical,'publisher'=>['@type'=>'Organization','name'=>$orgName,'url'=>$orgWebsite]]; if($socialImageUrl)$pageSchema['image']=$socialImageUrl; } elseif(!empty($page['answer_summary'])) $pageSchema['abstract']=(string)$page['answer_summary']; elseif(!empty($seoSettings['answer_summary'])) $pageSchema['abstract']=(string)$seoSettings['answer_summary'];
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#063f3e"><meta property="og:locale" content="en_LK"><?php $tabIcon=$favicon?public_upload($favicon):($logo?public_upload($logo):''); if($tabIcon):?><link rel="icon" type="image/png" href="<?=e($tabIcon)?>"><link rel="shortcut icon" href="<?=e($tabIcon)?>"><link rel="apple-touch-icon" sizes="180x180" href="<?=e($tabIcon)?>"><?php endif;?>
<title><?=e($pageTitle)?></title><meta name="description" content="<?=e($description)?>"><?php if($keywords):?><meta name="keywords" content="<?=e($keywords)?>"><?php endif;?><meta name="robots" content="index,follow,max-image-preview:large"><link rel="canonical" href="<?=e($canonical)?>">
<meta name="geo.region" content="<?=e($targetCountry.'-'.$targetDistrict)?>"><meta name="geo.placename" content="<?=e($targetLocality.', '.$targetDistrict)?>"><meta name="application-name" content="<?=e($orgName)?>">
<meta property="og:type" content="website"><meta property="og:title" content="<?=e($pageTitle)?>"><meta property="og:description" content="<?=e($description)?>"><meta property="og:url" content="<?=e($canonical)?>"><meta property="og:site_name" content="<?=e($orgName)?>"><?php if($socialImageUrl):?><meta property="og:image" content="<?=e($socialImageUrl)?>"><?php endif;?>
<?php if(!empty($heroPreload)):?><link rel="preload" as="image" href="<?=e(safe_image($heroPreload))?>" fetchpriority="high"><?php endif;?>
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="<?=e($pageTitle)?>"><meta name="twitter:description" content="<?=e($description)?>"><?php if($socialImageUrl):?><meta name="twitter:image" content="<?=e($socialImageUrl)?>"><?php endif;?>
<script type="application/ld+json"><?=seo_json($schema)?></script><?php if(isset($websiteSchema)):?><script type="application/ld+json"><?=seo_json($websiteSchema)?></script><?php endif;?><script type="application/ld+json" data-page-schema><?=seo_json($pageSchema)?></script>
<link rel="stylesheet" href="<?=asset('css/app.css')?>"></head><body>
<div id="page-loader" class="page-loader show" aria-hidden="true"><div class="loader-brand"><?php if($logoEnabled&&$logo):?><img src="<?=e(public_upload($logo))?>" alt=""><?php else:?><span class="loader-97">97</span><?php endif;?><i></i><b><?=e(strtoupper($orgName))?></b><small><?=e($foundation['tagline']??'Hope · Help · Humanity.')?></small></div></div>
<div class="topbar"><div class="container topbar-inner"><span>♥ Together, we can create a better tomorrow</span><div><a href="mailto:<?=e($foundation['email']??'info@97foundation.org')?>">✉ <?=e($foundation['email']??'info@97foundation.org')?></a><span class="sep">•</span><a href="tel:<?=e($foundation['phone']??'')?>">☎ <?=e($foundation['phone']??'+94 27 000 0000')?></a></div></div></div>
<header class="site-header" data-site-header><div class="container nav-wrap">
<a class="brand" href="<?=url('')?>" data-spa-link><?php if($logoEnabled&&$logo):?><img class="brand-upload" src="<?=e(public_upload($logo))?>" alt="<?=e($orgName)?> logo"><?php else:?><span class="brand-mark"><i></i><i></i><i></i></span><?php endif;?><span class="brand-copy"><b>97</b> FOUNDATION<small><?=e($foundation['tagline']??'Hope · Help · Humanity.')?></small></span></a>
<button class="mobile-toggle" data-menu-toggle aria-label="Open navigation">☰</button>
<nav class="main-nav" data-menu>
<a class="<?=nav_active('')?>" href="<?=url('')?>" data-spa-link>Home</a>
<a class="<?=nav_active('about')?>" href="<?=url('about')?>" data-spa-link>About Us</a>
<a class="<?=nav_active('causes')?>" href="<?=url('causes')?>" data-spa-link>Causes</a>
<a class="<?=nav_active('campaigns',true)?>" href="<?=url('campaigns')?>" data-spa-link>Campaigns</a>
<a class="<?=nav_active('events')?>" href="<?=url('events')?>" data-spa-link>Events</a>
<a class="<?=nav_active('gallery')?>" href="<?=url('gallery')?>" data-spa-link>Gallery</a>
<a class="<?=nav_active('members')?>" href="<?=url('members')?>" data-spa-link>Members</a>
<a class="<?=nav_active('news',true)?>" href="<?=url('news')?>" data-spa-link>News & Blog</a>
<a class="<?=nav_active('volunteer')?>" href="<?=url('volunteer')?>" data-spa-link>Volunteer</a>
<a class="<?=nav_active('contact')?>" href="<?=url('contact')?>" data-spa-link>Contact</a>
<a class="portal-link <?=nav_active('login')?>" href="<?=url('login')?>" data-spa-link>Login</a>
<a class="btn btn-primary btn-small" href="<?=url('donate')?>" data-spa-link>♥ Donate Now</a>
</nav></div></header>
<main data-spa-main><?=$content?></main>
<footer class="footer glass-footer"><div class="footer-ambient" aria-hidden="true"></div><div class="container footer-glass-shell"><div class="footer-grid"><div class="footer-brand-col"><a class="brand brand-footer" href="<?=url('')?>" data-spa-link><?php if($logoEnabled&&$logo):?><img class="brand-upload" src="<?=e(public_upload($logo))?>" alt="<?=e($orgName)?> logo"><?php else:?><span class="footer-logo-97">97</span><?php endif;?><span class="brand-copy"><b>97</b> FOUNDATION<small><?=e($foundation['tagline']??'Hope · Help · Humanity.')?></small></span></a><p>Creating positive change through compassion, community and accountable action across <?=e($targetDistrict)?> and surrounding communities.</p><div class="footer-rule"></div><div class="socials footer-socials"><?php foreach($socialLinks as $sl):$socialKind=social_platform_key($sl['platform'],$sl['url']);?><a class="social-link social-kind-<?=e($socialKind)?>" href="<?=e($sl['url'])?>" target="_blank" rel="noopener noreferrer" aria-label="<?=e($sl['label']?:$sl['platform'])?>" data-tooltip="<?=e($sl['label']?:$sl['platform'])?>" title="<?=e($sl['label']?:$sl['platform'])?>"><?=social_icon_svg($sl['platform'],$sl['url'])?></a><?php endforeach;?><?php if(!$socialLinks):?><span class="muted">Social links managed by Admin</span><?php endif;?></div></div>
<div class="footer-link-col"><h4>Quick Links</h4><a href="<?=url('about')?>" data-spa-link>› <span>About Us</span></a><a href="<?=url('causes')?>" data-spa-link>› <span>Our Causes</span></a><a href="<?=url('campaigns')?>" data-spa-link>› <span>Campaigns</span></a><a href="<?=url('gallery')?>" data-spa-link>› <span>Gallery</span></a><a href="<?=url('news')?>" data-spa-link>› <span>News & Blog</span></a></div>
<div class="footer-link-col"><h4>Get Involved</h4><a href="<?=url('donate')?>" data-spa-link>› <span>Donate</span></a><a href="<?=url('volunteer')?>" data-spa-link>› <span>Volunteer</span></a><a href="<?=url('events')?>" data-spa-link>› <span>Events</span></a><a href="<?=url('members')?>" data-spa-link>› <span>Foundation Members</span></a><a href="<?=url('member/register')?>" data-spa-link>› <span>Member Registration</span></a><a href="<?=url('member/login')?>" data-spa-link>› <span>Member Login</span></a></div>
<div class="footer-contact-col"><h4>Contact Info</h4><p><span class="footer-contact-icon"><?=contact_icon_svg('address')?></span><b><?=e($orgAddress)?></b></p><p><span class="footer-contact-icon"><?=contact_icon_svg('phone')?></span><b><?=e($foundation['phone']??'+94 27 000 0000')?></b></p><p><span class="footer-contact-icon"><?=contact_icon_svg('email')?></span><b><?=e($foundation['email']??'info@97foundation.org')?></b></p><p><span class="footer-contact-icon"><?=contact_icon_svg('website')?></span><b><?=e($orgWebsite)?></b></p><p><span class="footer-contact-icon"><?=contact_icon_svg('hours')?></span><b><?=e($foundation['opening_hours']??'Mon - Fri: 8:00 AM - 6:00 PM')?></b></p></div>
<div class="footer-donate-col"><h4>Secure Donations</h4><a class="footer-qr-card" href="<?=url('donate')?>" data-spa-link aria-label="Open donation page"><div class="footer-qr" data-qr-code data-qr-text="<?=e(absolute_url('donate'))?>"></div><span>Scan to Donate</span><small>Account details are managed by authorized administrators.</small></a></div></div>
<div class="footer-lower"><div class="footer-support-note"><span class="footer-lower-icon">♡</span><div><b>Your support helps us</b><small>create a better tomorrow.</small></div></div><div class="footer-metric"><span class="footer-lower-icon">✓</span><div><b><?=number_format($footerDonationCount)?></b><small>Verified Donations</small></div></div><div class="footer-metric"><span class="footer-lower-icon">♧</span><div><b><?=number_format($footerVolunteerCount)?></b><small>Active Volunteers</small></div></div><div class="footer-copyright"><b>© <?=date('Y')?> <?=e($orgName)?>. All rights reserved.</b><small>Fully Developed by 97 Foundation IT Team.</small></div></div></div></footer>

<?php $waNumber=preg_replace('/\D+/','',(string)($foundation['whatsapp']??$foundation['phone']??''));?>
<?php if($waNumber):?><a class="floating-whatsapp" href="https://wa.me/<?=e($waNumber)?>" target="_blank" rel="noopener noreferrer" aria-label="Contact 97 Foundation on WhatsApp" title="WhatsApp 97 Foundation"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 3.5A11.8 11.8 0 0 0 12.1 0C5.5 0 .2 5.3.2 11.9c0 2.1.6 4.1 1.6 5.9L0 24l6.4-1.7a12 12 0 0 0 5.7 1.5h.1c6.6 0 11.9-5.3 11.9-11.9 0-3.2-1.3-6.2-3.6-8.4Zm-8.4 18.3c-1.8 0-3.6-.5-5.1-1.4l-.4-.2-3.8 1 1-3.7-.2-.4A9.8 9.8 0 1 1 12.1 21.8Zm5.4-7.4c-.3-.2-1.8-.9-2.1-1-.3-.1-.5-.2-.7.2-.2.3-.8 1-1 1.2-.2.2-.4.2-.7.1-1.8-.9-3-1.6-4.2-3.6-.3-.5.3-.5.9-1.6.1-.2.1-.4 0-.6-.1-.2-.7-1.7-1-2.3-.3-.7-.6-.6-.8-.6h-.7c-.2 0-.6.1-.9.4-.3.3-1.2 1.2-1.2 2.9 0 1.7 1.2 3.3 1.4 3.6.2.2 2.4 3.7 5.9 5.2.8.4 1.5.6 2 .7.8.3 1.6.2 2.2.1.7-.1 1.8-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.4Z"/></svg><span>WhatsApp</span></a><?php endif;?>

<div class="live-chat-widget" data-live-chat data-chat-base="<?=e(url('chat'))?>">
<button class="live-chat-launch" type="button" data-chat-toggle aria-label="Open live support chat"><span class="chat-launch-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 9.8 9.8 0 0 1-3.7-.8L3 21l1.6-4.7A8.1 8.1 0 0 1 3 11.5 8.5 8.5 0 0 1 12 3a8.5 8.5 0 0 1 9 8.5Z"/><path d="M8 11.5h.01M12 11.5h.01M16 11.5h.01"/></svg></span><b>Live Chat</b><small>We are here to help</small></button>
<section class="live-chat-panel" aria-hidden="true" data-chat-panel-state="start">
<header><div><b>97 Foundation Support</b><small data-chat-header-status>Secure website chat</small></div><button type="button" data-chat-close aria-label="Minimize support chat">×</button></header>
<div class="live-chat-body" data-chat-body>
<section class="live-chat-start-state" data-chat-state-start>
<div class="chat-welcome"><span>97</span><h3>Hello 👋</h3><p>How can 97 Foundation help you today?</p></div>
<form data-chat-start-form data-no-loader><?=csrf_field()?><label><span>Name *</span><input name="name" required maxlength="120" autocomplete="name"></label><label><span>Email *</span><input name="email" type="email" required maxlength="190" autocomplete="email"></label><label><span>Phone</span><input name="phone" maxlength="60" autocomplete="tel"></label><label><span>Topic</span><select name="category"><option value="general">General Inquiry</option><option value="donation">Donation Support</option><option value="volunteer">Volunteer</option><option value="campaign">Campaign</option><option value="help">Need Help</option><option value="other">Other</option></select></label><label><span>Message *</span><textarea name="message" rows="4" required maxlength="3000" placeholder="Tell us how we can help…"></textarea></label><button class="btn btn-primary full" data-chat-start-button>Start Chat</button></form>
</section>
<section class="live-chat-active-state" data-chat-state-active hidden>
<div class="live-chat-thread" data-chat-thread role="log" aria-live="polite" aria-label="Support conversation"></div>
<div class="live-chat-closed-state" data-chat-closed-state hidden role="status"><span class="closed-state-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m7 12 3 3 7-7"/></svg></span><div class="closed-state-copy"><b>Support conversation completed</b><p>97 Foundation Support has closed this conversation. Thank you for contacting us.</p><small>You can start a new conversation whenever you need more help.</small></div><button type="button" data-chat-new><span>Start New Chat</span><b>↗</b></button></div>
<form class="live-chat-send" data-chat-send-form data-no-loader><?=csrf_field()?><div class="live-chat-composer"><textarea name="message" maxlength="3000" rows="1" placeholder="Type your message…" required data-chat-message-input></textarea><div class="live-chat-composer-tools"><small>Enter to send · Shift + Enter for new line</small><button class="widget-send-button" type="submit" data-chat-send-button><span>Send</span><b>➤</b></button></div></div></form>
</section>
</div>
<footer><span>🔒 Protected conversation</span><button type="button" data-chat-end hidden>Clear Chat</button></footer>
</section></div>
<div class="toast-stack" data-toast-stack></div><button class="back-top" data-back-top aria-label="Back to top">↑</button>
<script src="<?=asset('js/vendor/qrcode.min.js')?>" defer></script><script src="<?=asset('js/app.js')?>" defer></script></body></html>
